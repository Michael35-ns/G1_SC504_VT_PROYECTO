<?php $__env->startSection('dashboard'); ?>
    <aside class="main-sidebar bg-gray-800">
        <a href="#" class="flex items-center p-4">
            <img src="public/img/Logo.png" alt="FindMyPet! Logo" class="w-9 h-9 rounded-full opacity-80">
            <span class="ml-2 text-white font-bold"><strong>FindMyPet!</strong></span>
        </a>

        <div class="sidebar">
            <nav class="mt-2">
                <ul class="space-y-2">
                    <li class="nav-item">
                        <a href="#" class="flex items-center p-2 text-white hover:bg-gray-700 rounded-md">
                            <img src="public/img/Animales.png" alt="Animales" class="w-6 h-6">
                            <span class="ml-3">Animales</span>
                            <svg class="ml-auto w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7">
                                </path>
                            </svg>
                        </a>
                        <ul class="pl-8 space-y-1 mt-1 hidden">
                            <li>
                                <a href="#" class="flex items-center p-2 text-white hover:bg-gray-700 rounded-md">Ver
                                    todas las mascotas</a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="flex items-center p-2 text-white hover:bg-gray-700 rounded-md">
                            <img src="public/img/Productos.png" alt="Productos" class="w-6 h-6">
                            <span class="ml-3">Productos</span>
                            <svg class="ml-auto w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7">
                                </path>
                            </svg>
                        </a>
                        <ul class="pl-8 space-y-1 mt-1 hidden">
                            <li>
                                <a href="#" class="flex items-center p-2 text-white hover:bg-gray-700 rounded-md">Ver
                                    productos</a>
                            </li>
                            <li>
                                <a href="#"
                                    class="flex items-center p-2 text-white hover:bg-gray-700 rounded-md">Publicar un
                                    producto</a>
                            </li>
                            <li>
                                <a href="#"
                                    class="flex items-center p-2 text-white hover:bg-gray-700 rounded-md">Eliminar un
                                    producto</a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="flex items-center p-2 text-white hover:bg-gray-700 rounded-md">
                            <img src="public/img/PublicarAnimal.png" alt="PublicarAnimal" class="w-6 h-6">
                            <span class="ml-3">Publicar un animal</span>
                            <svg class="ml-auto w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7">
                                </path>
                            </svg>
                        </a>
                        <ul class="pl-8 space-y-1 mt-1 hidden">
                            <li>
                                <a href="#"
                                    class="flex items-center p-2 text-white hover:bg-gray-700 rounded-md">Publicar un
                                    animal</a>
                            </li>
                            <li>
                                <a href="#"
                                    class="flex items-center p-2 text-white hover:bg-gray-700 rounded-md">Eliminar una
                                    publicación</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" class="flex items-center p-2 text-white hover:bg-gray-700 rounded-md">
                            <img src="public/img/Donar.png" alt="Donar" class="w-6 h-6">
                            <span class="ml-3">Realizar una donación</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\fabia\Documents\Universidad\V Cuatri\Lenguajes DB\Proyecto\G1_SC504_VT_PROYECTO\WiseWallet\resources\views/dashboard.blade.php ENDPATH**/ ?>