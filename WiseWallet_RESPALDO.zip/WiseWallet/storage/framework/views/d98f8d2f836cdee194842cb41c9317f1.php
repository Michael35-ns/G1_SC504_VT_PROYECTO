

<?php $__env->startSection('titulo'); ?>
    Editar Transacción
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <section class="hidden sm:grid grid-cols-3 gap-6 justify-items-center">

        
        <div class="col-span-1 bg-white p-6 rounded-lg shadow-md w-full max-w-lg">
            <h3 class="text-lg font-semibold mb-4">Editar Ingreso</h3>

            <form action="<?php echo e(route('editarIngreso', $ingreso->id_ingreso)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-4">
                    <label for="categoria" class="block text-sm font-medium text-gray-700">Categoría</label>
                    <select id="categoria" name="id_transaccion" class="border border-gray-300 rounded w-full py-2 px-4">
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($categoria['ID_TRANSACCION']); ?>"
                                <?php echo e(old('id_transaccion', $ingreso->id_transaccion) == $categoria['ID_TRANSACCION'] ? 'selected' : ''); ?>>
                                <?php echo e($categoria['TIPO_TRANSACCION']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_transaccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="descripcion" class="block text-sm font-medium text-gray-700">Descripción</label>
                    <textarea id="descripcion" name="descripcion" class="border border-gray-300 rounded w-full py-2 px-4"><?php echo e(old('descripcion', $ingreso->descripcion_ingreso)); ?></textarea>
                    <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="fecha" class="block text-sm font-medium text-gray-700">Fecha del ingreso</label>
                    <input type="date" id="fecha" name="fecha_ingreso"
                        value="<?php echo e(old('fecha_ingreso', $ingreso->FECHA_INGRESO)); ?>"
                        class="border border-gray-300 rounded w-full py-2 px-4 text-gray-800">
                    <?php $__errorArgs = ['fecha_ingreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="monto" class="block text-sm font-medium text-gray-700">Monto</label>
                    <input type="number" id="monto" name="monto_ingreso"
                        value="<?php echo e(old('monto_ingreso', $ingreso->MONTO_INGRESO)); ?>"
                        class="border border-gray-300 rounded w-full py-2 px-4 text-gray-800">
                    <?php $__errorArgs = ['monto_ingreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="estado"
                        class="block text-sm mb-1 font-medium border-gray-300 text-gray-700">Estado</label>
                    <select id="estado" name="id_estado"
                        class="w-full p-2 rounded bg-slate-400 text-white border-gray-300 py-2 px-4">
                        <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($estado['ID_ESTADO']); ?>"
                                <?php echo e(old('id_estado', $ingreso->ID_ESTADO) == $estado['ID_ESTADO'] ? 'selected' : ''); ?>>
                                <?php echo e($estado['TIPO_ESTADO']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex justify-end space-x-4">
                    <a href="<?php echo e(route('Ingreso')); ?>" class="py-2 px-4 bg-gray-500 text-white rounded">Cancelar</a>
                    <button type="submit" class="py-2 px-4 bg-green-500 text-white rounded">Actualizar</button>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Diego\Documents\GitHub\G1_SC504_VT_PROYECTO\WiseWallet\resources\views\Ingresos\editar.blade.php ENDPATH**/ ?>