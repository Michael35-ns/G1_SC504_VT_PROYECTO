
<?php $__env->startSection('titulo'); ?>
    Grafico
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Diego\Documents\GitHub\G1_SC504_VT_PROYECTO\WiseWallet\resources\views\grafico.blade.php ENDPATH**/ ?>