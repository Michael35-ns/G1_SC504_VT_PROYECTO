@extends('layouts.app')
@section('titulo')
    Grafico
@endsection

@section('contenido')
    
@endsection
